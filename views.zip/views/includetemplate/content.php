 <div class="right_col" role="main">

                <br />
 <!-- page content -->
           <!--  <div class="right_col" role="main"> -->
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Add AD Form</h3>
                        </div>
<!-- 
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel" >
                                <div class="x_title">
                                    <h2>Add AD</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>                                   
                                </div>                             
                                <div class="row">
                                <!-- left column -->
                                    <div class="col-md-12">

                                        <form id="demo-form2" class="form-horizontal form-label-left" action="<?=base_url()?>add_advt" method="POST" role="form" enctype="multipart/form-data">
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Venders Name: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="vender" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Seller Name: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="adv_v_name" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">seller Mobile: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="adv_mobile" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">seller Email: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="adv_email" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Description: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <textarea size="20" class="form-control col-md-7 col-xs-12" type="text" name="desc" required></textarea> 
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Photo: </label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20"  type="file" name="image"  >
                                                </div>
                                            </div>
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category-name">Category: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <select class="form-control col-md-7 col-xs-12" name="category" required>
                                                       <?php 
                                                        $data=array('status'=>1,'del_status'=>0);
                                                        $query_category=$this->db->get_where('category',$data);
                                                        if($query_category->num_rows()==0){
                                                            echo '<option value="">--Add Category--</option>';
                                                        }else{
                                                           echo '<option value="">--Select Category--</option>';
                                                            foreach ($query_category->result() as  $value) {?>
                                                                <option value="<?=$value->adv_category?>"><?=$value->cat_name?></option>
                                                           <?php }
                                                        }?>
                                                    </select>                                                   
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price-name">Price: <span style="color:red">*(In Rs)</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="price" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Duration: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                     <input type="radio" name="duration" class="radio-inline" value="Day">Day
                                                     <input type="radio" name="duration" class="radio-inline" value="Week">Week
                                                     <input type="radio" name="duration" class="radio-inline" value="Month">Month
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Size: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" min="1" name="size" required  >
                                                </div>
                                            </div>
                                             
                                            <div class="box-body">
                                                <div class="form-group">                                                
                                                <div id="map-canvas"></div>
                                                </div>
                                            </div>
                                            <!-- /.box-body -->
                                             
                                            
                                                <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Address <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="address_des"  type="text" id="address1" readonly="">
                                                </div>
                                            </div>                                           
                                            <div id="latlong">
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Latitude:</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                                        <input size="20" type="text" class="form-control col-md-7 col-xs-12" id="latbox" name="lat" readonly >
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Longitude:</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                                        <input size="20" class="form-control col-md-7 col-xs-12" type="text" id="lngbox" name="lng" readonly="">
                                                    </div>
                                                </div>
                                            </div>                                    
                                            <div class="box-footer">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div><!-- /.box -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
              <!--  <footer>
                    <div class="">
                        <p class="pull-right">Gentelella Alela! a Bootstrap 3 template by <a>Kimlabs</a>. |
                            <span class="lead"> <i class="fa fa-paw"></i> Gentelella Alela!</span>
                        </p>
                    </div>
                   <!--  <div class="clearfix"></div> -->
              <!--   </footer> --> 
                <!-- /footer content -->
            </div>
            <!-- /page content -->
        </div>
    </div>
    <style>
    #pac-input {
  background-color: #fff;
  font-family: Roboto;
  font-size: 15px;
  font-weight: 300;
  margin-left: 12px;
  padding: 0 11px 0 13px;
  text-overflow: ellipsis;
  width: 300px;
}

#pac-input:focus {
  border-color: #4d90fe;
}

.pac-container {
  font-family: Roboto;
}

 #map-canvas {
        height: 500px;
        margin: 0px;
        padding: 0px
      }
</style>  
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script>
  var map;
      var geocoder;
      var mapOptions = { center: new google.maps.LatLng(0.0, 0.0), zoom: 2,
        mapTypeId: google.maps.MapTypeId.ROADMAP };

      function initialize() {
var myOptions = {
                center: new google.maps.LatLng(20.296059, 85.82454),
                zoom: 3,
                mapTypeId: google.maps.MapTypeId.TERRAIN
                            };

            geocoder = new google.maps.Geocoder();
            var map = new google.maps.Map(document.getElementById("map-canvas"),
            myOptions);
            google.maps.event.addListener(map, 'click', function(event) {
                placeMarker(event.latLng);
            });

            var marker;
            function placeMarker(location) {
                if(marker){ //on vérifie si le marqueur existe
                    marker.setPosition(location); //on change sa position
                }else{
                    marker = new google.maps.Marker({ //on créé le marqueur
                        position: location,
                        map: map
                    });
                }
                document.getElementById('latbox').value=location.lat();
                document.getElementById('lngbox').value=location.lng();
                getAddress(location);
            }

      function getAddress(latLng) {
        geocoder.geocode( {'latLng': latLng},
          function(results, status) {
            if(status == google.maps.GeocoderStatus.OK) {
              if(results[0]) {
                document.getElementById("address1").value = results[0].formatted_address;
              }
              else {
                document.getElementById("address1").value = "No results";
              }
            }
            else {
              document.getElementById("address1").value = status;
            }
          });
        }
      }
      google.maps.event.addDomListener(window, 'load', initialize);    </script>
