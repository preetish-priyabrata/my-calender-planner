 <div class="right_col" role="main">

                <br />
 <!-- page content -->
           <!--  <div class="right_col" role="main"> -->
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Add AD Form</h3>
                        </div>
<!-- 
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel" >
                                <div class="x_title">
                                    <h2>Add AD</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>                                   
                                </div>                             
                                <div class="row">
                                <!-- left column -->
                                    <div class="col-md-12">

                                        <form id="demo-form2" class="form-horizontal form-label-left" action="<?=base_url()?>add_advt" method="POST" role="form">
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Venders Name: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="vender" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Description: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <textarea size="20" class="form-control col-md-7 col-xs-12" type="text" name="desc" required></textarea> 
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Photo: </label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20"  type="file" name="image"  >
                                                </div>
                                            </div>
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category-name">Category: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <select class="form-control col-md-7 col-xs-12" name="category" required>
                                                        <option value=""></option>
                                                        <option value="1">Appartment</option>
                                                        <option value="2">Malls</option>
                                                        <option value="3">Streets</option>
                                                        <option value="4">Tv</option>
                                                        <option value="4">Radio</option>
                                                    </select>                                                   
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price-name">Price: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="price" required  >
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Duration: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="number" min="1" name="duration" required  >
                                                </div>
                                            </div>
                                             <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="size">Size:</label>
                                                <div class="col-md-3 col-sm-3 col-xs-12">
                                                 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="width-name">width:</label>
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="width">
                                                </div>
                                                <div class="col-md-3 col-sm-3 col-xs-12">
                                                 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="height-name">Height:</label>
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="heigth">
                                                </div>
                                            </div>
                                            <div class="box-body">
                                                <div class="form-group">                                                
                                                <div id="map-canvas"></div>
                                                </div>
                                            </div>
                                            <!-- /.box-body -->
                                             <div class="form-group">                                            
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="marker-status">Marker status:</label>
                                                <div id="markerStatus" class="col-md-6 col-sm-6 col-xs-12">
                                                    <i>Click and drag the marker.</i>                                              
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="current-postion">Current position:</label>
                                                <div id="info"  class="col-md-6 col-sm-6 col-xs-12"></div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="closer-matching">Closest matching address:</label>
                                                <div id="address"  class="col-md-6 col-sm-6 col-xs-12"></div>
                                            </div>
                                                <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Address <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="address_des"  type="text" id="address1" readonly="">
                                                </div>
                                            </div>                                           
                                            <div id="latlong">
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Latitude:</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                                        <input size="20" type="text" class="form-control col-md-7 col-xs-12" id="latbox" name="lat" readonly >
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Longitude:</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                                        <input size="20" class="form-control col-md-7 col-xs-12" type="text" id="lngbox" name="lng" readonly="">
                                                    </div>
                                                </div>
                                            </div>                                    
                                            <div class="box-footer">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div><!-- /.box -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
              <!--  <footer>
                    <div class="">
                        <p class="pull-right">Gentelella Alela! a Bootstrap 3 template by <a>Kimlabs</a>. |
                            <span class="lead"> <i class="fa fa-paw"></i> Gentelella Alela!</span>
                        </p>
                    </div>
                   <!--  <div class="clearfix"></div> -->
              <!--   </footer> --> 
                <!-- /footer content -->
            </div>
            <!-- /page content -->
        </div>
    </div>
    <style>
 #map-canvas {
        height: 500px;
        margin: 0px;
        padding: 0px
      }
</style>  
 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">
var geocoder = new google.maps.Geocoder();

function geocodePosition(pos) {
  geocoder.geocode({
    latLng: pos
  }, function(responses) {
    if (responses && responses.length > 0) {
      updateMarkerAddress(responses[0].formatted_address);
    } else {
      updateMarkerAddress('Cannot determine address at this location.');
    }
  });
}

function updateMarkerStatus(str) {
  document.getElementById('markerStatus').innerHTML = str;
}

function updateMarkerPosition(latLng) {
 
    document.getElementById("latbox").value =latLng.lat();
   document.getElementById("lngbox").value = latLng.lng();
 document.getElementById('info').innerHTML = [
    latLng.lat(),
    latLng.lng()
  ].join(', ');
}

function updateMarkerAddress(str) {
  //alert(str);
  document.getElementById('address').innerHTML = str;
    document.getElementById('address1').value=str;
}

function initialize() {
  var latLng = new google.maps.LatLng(20.9516658, 85.09852360000002);
  var map = new google.maps.Map(document.getElementById('map-canvas'), {
    zoom: 8,
    center: latLng,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  var marker = new google.maps.Marker({
    position: latLng,
    title: 'Point A',
    map: map,
    draggable: true
  });
 
  // Update current position info.
  updateMarkerPosition(latLng);
  geocodePosition(latLng);
 
  // Add dragging event listeners.
  google.maps.event.addListener(marker, 'dragstart', function() {
    updateMarkerAddress('Dragging...');
  });
 
  google.maps.event.addListener(marker, 'drag', function() {
    updateMarkerStatus('Dragging...');
    updateMarkerPosition(marker.getPosition());
  });
 
  google.maps.event.addListener(marker, 'dragend', function() {
    updateMarkerStatus('Drag ended');
    geocodePosition(marker.getPosition());
  });
}

// Onload handler to fire off the app.
google.maps.event.addDomListener(window, 'load', initialize);
</script>