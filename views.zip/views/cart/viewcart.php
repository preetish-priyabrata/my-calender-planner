
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>
                    View Advt. Cart Detail
                    <small>
                       
                    </small>
                </h3>
                        </div>

                        <!-- <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                     <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Advance <small>Seaech</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                       
                                       
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                     <form class="form-horizontal form-bordered" role="form" action="<?=base_url();?>index.php/ordercontroller/search_advance_ordersummary" method="post">
                                 <!-- <div class="col-md-3 col-sm-12">
 -->                                  <div class="form-group">
                                      <div class="col-md-4 text-right">
                                          <label class="">Campaign Status<span style="color:red">*</span> :</label>
                                        </div>
                                      <div class="col-md-7 col-xs-12">
                                                <select class="col-md-6 col-sm-6 col-xs-12">
                                                <option value="">--Select Status--</option>
                                                    <option value="1">Campaign Selected</option>
                                                    <option value="2">Communication pending from ShopAdSpace.com</option>
                                                    <option value="3">Communication pending from Client</option>
                                                    <option value="4">Creative Submitted</option>
                                                    <option value="5">Campaign Started</option>
                                                    <option value="6">Campaign Completed</option>
                                                </select>
                                            </div>
                                 
                                    <button type="submit" name="mobis"class="btn btn-primary btn-sm">Search</button> 
                                  <!-- </div> -->
                                  </div>                      
                                </form>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>View Advt. Cart <small>Detail</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                       
                                        <li><a href="#" class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>Serial Nos</th>
                                                <th>Name</th>
                                                <th>Email </th>
                                                <th>Mobile</th>
                                                <th>Advt.Id</th>
                                               
                                                <!-- <th class=" no-link last"><span class="nobr">Action</span>
                                                </th> -->
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
                                        $x=1;
                                         $this->db->order_by("ca_id","desc");
                                        $query=$this->db->get('advt_cart');
                                        foreach ($query->result() as $key) {?>
                                       
                                            <tr class="headings">
                                                <th><?=$x?></th>
                                                <th><?=$key->name?></th>
                                                <th><?=$key->email?></th>
                                                 <th><?=$key->mobile?></th>
                                                  <th><?=$key->adv_codeid?></th>
                                               
                                            </tr>

                                            <?php 
                                                $x++;
                                            } ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                </div>
</div>

 