
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>
                    View News-Paper Price Detail
                    <small>
                       
                    </small>
                </h3>
                        </div>

                        <!-- <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>View News-Paper Price<small>Detail</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <!-- <li><a href="#"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li> -->
                                        <li><a href="#" class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                 <div> 
                                    <a href="<?=base_url()?>price-add-news"  class="fa fa-plus-square text-success pull-right" style="font-size: 30px;"  ></a>
                                    </div>
                                <div class="x_content">
                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>Serial Nos</th>                                               
                                                <th >News-Paper</th>
                                                 <th>Location</th>
                                                  <th>Page</th>
                                                  <th>Price</th>
                                                <th >Status</th>
                                                <th >Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
                                        $x=1;
                                         $data=array('del_status'=>0);
                                        $query=$this->db->get_where('news_price',$data);
                                        foreach ($query->result() as $key) {?>
                                       
                                            <tr class="headings">
                                                <td><?=$x?></td>
                                                <td><?php $code=$key->ne_code;
                                                $data_match = array('ne_code' =>$code);
                                                $query_match=$this->db->get_where('news_table',$data_match);
                                                foreach ($query_match->result() as  $value) {
                                                    echo $value->ne_new_name;
                                                }

                                                ?></td>
                                                 <td><?=$key->location?></td>
                                                 <td><?=$key->page?></td>
                                                  <td><?=$key->price?></td>
                                                <td ><?php          
                                                        if ($key->status==1){
                                                    ?>
                                                            <a href="<?php echo site_url('update-news-price-status/2/'.$key->pr_id)?>" name='active' class='badge bg-green' style='cursor:pointer;'>Active</a>
                                                    <?php 
                                                        }else{
                                                    ?>
                                                            <a href='<?php echo site_url('update-news-price-status/1/'.$key->pr_id)?>' name='inactive' class='badge bg-red' style='cursor:pointer;'>Inactive</a>
                                                    <?php 
                                                        }                   
                                                    ?></td>
                                                <td><a href="<?php echo site_url('update-news-price-update-form/'.$key->pr_id)?>" class="fa fa-pencil-square-o" style="color:green" ></a> || <a href="" class="fa fa-close" style="color:red" data-toggle="modal" data-target="#myModal<?=$key->pr_id?>"></a>
                                         
                                            </td>

                                               
                                                
                                            </tr>
<div id="myModal<?=$key->pr_id?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:red">Do You Want To Delete ...</span></h4>
      </div>
      <div class="modal-body">
      <form id="preevender<?=$key->pr_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>delete-news-price" method="POST" role="form" enctype="multipart/form-data">
        <input type="hidden" name="pr_id" value="<?=$key->pr_id?>">
          <label> <b>New-Paper Name</b> </label>:<?php $code=$key->ne_code;
                            $data_match = array('ne_code' =>$code);
                            $query_match=$this->db->get_where('news_table',$data_match);
                            foreach ($query_match->result() as  $value) {
                                echo $value->ne_new_name;
                            }

                            ?><br>
       <label> <b>Location Name</b> </label>: <?=$key->location?>.<br>
       <label> <b>Page Name</b> </label>: <?=$key->page?>.<br>
       <label> <b>Price Name</b> </label>: <?=$key->price?>.<br> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-round btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-round btn-danger"  >Delete</button>
        
      </div>
    </div>
    </form>
  </div>
</div>
<!--delete modal -->
                                            <?php 
                                                $x++;
                                            } ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                </div>
</div>