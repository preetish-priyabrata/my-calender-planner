
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>
                    View Advt. Detail
                    <small>
                       
                    </small>
                </h3>
                        </div>

                        <!-- <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>View Advt. <small>Detail</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <!-- <li><a href="#"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li> -->
                                        <li><a href="#" class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                 <div> 
                                    <a href="<?=base_url()?>Adform"  class="fa fa-plus-square text-success pull-right" style="font-size: 30px;"  ></a>
                                </div>
                                <div class="x_content">
                                 <div class="col-md-12 col-xs-12 table-responsive">
                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>Serial Nos</th>
                                                <th>Vender Name</th>
                                                <th>Seller Name</th>
                                                <th>Seller Email</th>
                                                <th>Seller Mobile</th>
                                                <th>Price </th>
                                                <th>Category</th>
                                                <th>Address</th>
                                                <th>Duration</th>
                                                <th>Lat/Lng</th>
                                                <th>Size</th>
                                                <th>status</th>
                                                <th >Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
                                        $x=1;
                                         $data=array('del_status'=>0);
                                        $query=$this->db->get_where('advt_table',$data);
                                        foreach ($query->result() as $key) {if($key->addby==1){?>
                                            
                                            <tr class="headings" style="background:rgb(0, 0, 42)">
                                            <?php }else{?>
                                             <tr class="headings" >
                                          <?php  } ?>
                                                <th><?=$x?></th>
                                                <th><?=$key->adv_vender?></th>
                                                 <th><?=$key->adv_v_name?></th>
                                                 <th><?=$key->adv_email?></th>
                                                 <th><?=$key->adv_mobile?></th> 

                                                <th><?=$key->adv_price?></th>
                                                <th>
                                               <?php $cat=$key->adv_category;
                                               $data_cat=array('adv_category'=>$cat);
                                               $query_cat=$this->db->get_where('category',$data_cat);
                                               foreach ($query_cat->result() as $value) {
                                                 echo $value->cat_name;
                                               }?>
                                                </th>
                                                <th><?=$key->address_desc?></th>
                                                <th><?=$key->duration?></th>
                                                <th><?=$key->lat?>/<?=$key->lng?></th>
                                                <th><?=$key->size?></th>
                                                 <th><?php          
                                                        if ($key->status==1){
                                                    ?>
                                                            <a href="<?php echo site_url('update-directstatus/2/'.$key->adv_id)?>" name='active' class='badge bg-green' style='cursor:pointer;'>Active</a>
                                                    <?php 
                                                        }else{
                                                    ?>
                                                            <a href='<?php echo site_url('update-directstatus/1/'.$key->adv_id)?>' name='inactive' class='badge bg-red' style='cursor:pointer;'>Inactive</a>
                                                    <?php 
                                                        }                   
                                                    ?>
                                                </th>     
                                                <th ><a href="<?php echo site_url('update-direct-form/'.$key->adv_codeid)?>" class="fa fa-pencil-square-o" style="color:green" ></a> || <a href="" class="fa fa-close" style="color:red" data-toggle="modal" data-target="#myModal<?=$key->adv_codeid?>"></a>
                                                </th>
                                            </tr>
                                                <!-- Modal -->
<div id="myModal<?=$key->adv_codeid?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:red">Do You Want To Delete ...</span></h4>
      </div>
      <div class="modal-body">
       <form id="preevender<?=$key->adv_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>delete-direct" method="POST" role="form" enctype="multipart/form-data">
        <input type="hidden" name="adv_id" value="<?=$key->adv_id?>">
        <label> <b>vender Name</b> </label>: <?=$key->adv_vender?>.<br>
        <label><b> Address</b> : <?=$key->address_desc?>. </label> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-round btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-round btn-danger"  >Delete</button>        
      </div>
    </div>
    </form>

  </div>
</div>
<!-- modal -->
                                            <?php 
                                                $x++;
                                            } ?>
                                        </tbody>

                                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                </div>
</div>