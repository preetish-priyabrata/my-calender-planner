 <div class="right_col" role="main">

                <br />
 <!-- page content -->
           <!--  <div class="right_col" role="main"> -->
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Add Radio Price</h3>
                        </div>
<!-- 
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel" >
                                <div class="x_title">
                                    <h2>Add Radio Price</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>                                   
                                </div>                             
                                <div class="row">
                                <!-- left column -->
                                    <div class="col-md-12">

                                        <form id="preevender" class="form-horizontal form-label-left" action="<?=base_url()?>price-radio" method="POST" role="form" enctype="multipart/form-data">
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Radio Name: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                <select class="form-control col-md-7 col-xs-12" type="text" name="radio" id="rad" required> 
                                               
                                                <?php 
                                                $data = array('status' =>1);
                                                    $query=$this->db->get_where('radio_table',$data) ;
                                                    if($query->num_rows()==0){
                                                        echo "<option value=''>--Add Radio--</option>";
                                                    }else{
                                                        echo "<option value=''>--Select Radio--</option>";
                                                        foreach ($query->result() as $key) {
                                                         
                                                      
                                                        ?>

                                                        <option value="<?=$key->ra_code?>"><?=$key->ra_name?></option>
                                                  <?php } }
                                                  ?>
                                                

                                                </select>
                                                  
                                                    
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Locations: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12"  type="text" name="location" id="loc"  >
                                                </div>
                                            </div>
                                            
                                             <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Price: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12"  type="text" name="price" id="price"  >
                                                </div>
                                            </div>
                                         <span id="errornews" style="color:red" ></span>
                                                                               
                                            <div class="box-footer">
                                            <button type="button" class="btn btn-primary" onclick="news_check()">Submit</button>
                                            </div>
                                        </form>
                                    </div><!-- /.box -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
              <!--  <footer>
                    <div class="">
                        <p class="pull-right">Gentelella Alela! a Bootstrap 3 template by <a>Kimlabs</a>. |
                            <span class="lead"> <i class="fa fa-paw"></i> Gentelella Alela!</span>
                        </p>
                    </div>
                   <!--  <div class="clearfix"></div> -->
              <!--   </footer> --> 
                <!-- /footer content -->
            </div>
            <!-- /page content -->
        </div>
    </div>
    <script type="text/javascript">
    function news_check(){
        var loc=$('#loc').val();
       
        var rad=$('#rad').val();
        if(rad!="" &&  loc!="" ){
            $.ajax({
                type: "POST",
                url: "<?=base_url();?>index.php/admindash/checkradioprice/",
                 data: {rad:rad,loc:loc},
                success: function(result)   {
                    if(result==1){
                         document.getElementById("errornews").innerHTML = "";
                        $("#preevender").submit(); 
                    }else{
                      document.getElementById("errornews").innerHTML = "Same Radio With Locatiom "+loc;
                      return false;
                    }
                }
                });
        }else{
            document.getElementById("errornews").innerHTML = "Some Mandatory Field Is Blank";
            return false;

        }
        

    }
    </script>
