
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>
                    View Radio Detail
                    <small>
                       
                    </small>
                </h3>
                        </div>

                        <!-- <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>View Radio <small>Detail</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <!-- <li><a href="#"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li> -->
                                        <li><a href="#" class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>

                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                 <div> 
                                    <a href="<?=base_url()?>radioform"  class="fa fa-plus-square text-success pull-right" style="font-size: 30px;"  ></a>
                                    </div>
                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>Serial Nos</th>
                                               
                                                <th >Image</th>
                                                 <th>Radio</th>
                                                  <th >Status</th>
                                                <th >Action</th>
                                                
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
                                        $x=1;
                                         $data=array('del_status'=>0);
                                        $query=$this->db->get_where('radio_table',$data);
                                        foreach ($query->result() as $key) {?>
                                       
                                            <tr class="headings">
                                                <td><?=$x?></td>
                                               
                                                
                                                    <?php 
                                                    if(!empty($key->ra_image)){?>
                                                   <td style="width:40%"> <img src="<?=base_url('uploads').'/'.$key->ra_image;?>" style="width:25%; height:25%;"></td>
                                                       
                                                    <?php }else{
                                                        echo ' <td style="width:40%"> Image Not Available</td>';
                                                    }

                                                    ?>

                                               
                                                <td><p style="vertical-align: middle;"><?=$key->ra_name?></p></td>
                                                <th ><?php          
                                                        if ($key->status==1){
                                                    ?>
                                                            <a href="<?php echo site_url('update-radiostatus/2/'.$key->ra_id)?>" name='active' class='badge bg-green' style='cursor:pointer;'>Active</a>
                                                    <?php 
                                                        }else{
                                                    ?>
                                                            <a href='<?php echo site_url('update-radiostatus/1/'.$key->ra_id)?>' name='inactive' class='badge bg-red' style='cursor:pointer;'>Inactive</a>
                                                    <?php 
                                                        }                   
                                                    ?></th>
                                                <th ><a href="" class="fa fa-pencil-square-o" style="color:green" data-toggle="modal" data-target="#myeditmodal<?=$key->ra_id?>"></a> || <a href="" class="fa fa-close" style="color:red" data-toggle="modal" data-target="#myModal<?=$key->ra_id?>"></a>
                                         
                                            </th>
                                            </tr>
<div id="myeditmodal<?=$key->ra_id?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:blue">Edit Radio</span></h4>
      </div>   
        <form id="preevender<?=$key->ra_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>update-radio" method="POST" role="form" enctype="multipart/form-data">
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                    <label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-name">Radio Name: <span style="color:red">*</span></label>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <input type="hidden" name="ra_id" value="<?=$key->ra_id?>" id="ra_id<?=$key->ra_id?>">
                        <input size="20" class="form-control col-md-7 col-xs-12" type="text" value="<?=$key->ra_name?>" name="ra_name" id="cat<?=$key->ra_id?>" Placeholder="Enter Radio Name"  required  >
                        <span id="errornews<?=$key->ra_id?>" style="color:red" ></span>
                    </div>
                    <label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-Image">Image of Radio: </label>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <input size="20"  type="file" name="image" required id="img<?=$key->ra_id?>"  >
                        <span id="errorimage<?=$key->ra_id?>" style="color:red" ></span>
                    </div>                                               
              </div>
            </div>
          <!-- <div class="modal-footer"> -->
            <div class="modal-footer">
                <button type="button" onclick="mycategory(<?=$key->ra_id?>)" class="btn btn-primary" >Submit</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </form>
       
    </div>

  </div>
</div>
<!--edit modal -->
                                                <!--delete Modal -->
<div id="myModal<?=$key->ra_id?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:red">Do You Want To Delete ...</span></h4>
      </div>
      <div class="modal-body">
      <form id="preevender<?=$key->ra_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>delete-radio" method="POST" role="form" enctype="multipart/form-data">
        <input type="hidden" name="ra_id" value="<?=$key->ra_id?>">
       <label> <b>Radio Name</b> </label>: <?=$key->ra_name?>.<br>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-round btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-round btn-danger"  >Delete</button>
        
      </div>
    </div>
    </form>
  </div>
</div>
<!--delete modal -->
                          
                                            <?php 
                                                $x++;
                                            } ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                </div>
</div>

<script type="text/javascript">
    function mycategory(id){
        var cat=$('#cat'+id).val();
        var catid=$('#ra_id'+id).val();
        
        if(cat!=""){            
                $.ajax({
                    type: "POST",
                    url: "<?=base_url();?>index.php/admindash/checkradios/",
                     data: {cat:cat,catid:catid},
                    success: function(result)   {
                        if(result==1){
                             document.getElementById("errornews"+id).innerHTML = "";
                            $("#preevender"+id).submit(); 
                        }else{
                          document.getElementById("errornews"+id).innerHTML = "Radio Is Used In Our List "+cat;
                          return false;
                        }
                    }
                });           
        }else{
            document.getElementById("errornews"+id).innerHTML = "Radio Should Not Left Blank";
            return false;

        }
        

    }
    </script>