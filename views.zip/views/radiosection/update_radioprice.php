 <div class="right_col" role="main">

                <br />
 <!-- page content -->
           <!--  <div class="right_col" role="main"> -->
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Add Radio Price</h3>
                        </div>
<!-- 
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel" >
                                <div class="x_title">
                                    <h2>Add Radio Price1</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>                                   
                                </div>                             
                                <div class="row">
                                <!-- left column -->
                                    <div class="col-md-12">
                                         <?php $pr_id=$newsid;
                                    $data = array('pr_id' =>$pr_id);
                                    $query1=$this->db->get_where('radio_price',$data);
                                    foreach ($query1->result() as $key1) {?>
                                        <form id="preevender" class="form-horizontal form-label-left" action="<?=base_url()?>price-update-radio" method="POST" role="form" enctype="multipart/form-data">
                                         <input type="hidden" value="<?=$key1->pr_id?>" name="pr_id" id="pr_id">
                                         <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Radio Name: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                <select class="form-control col-md-7 col-xs-12" type="text" name="radio" id="rad" required> 
                                               
                                                <?php 
                                                $data = array('status' =>1);
                                                    $query=$this->db->get_where('radio_table',$data) ;
                                                    if($query->num_rows()==0){
                                                        echo "<option value=''>--Add Radio--</option>";
                                                    }else{
                                                        echo "<option value=''>--Select Radio--</option>";
                                                        foreach ($query->result() as $key) {
                                                         
                                                      
                                                        ?>

                                                        <option value="<?=$key->ra_code?>" <?php if($key1->ra_code==$key->ra_code){echo "selected";}?>><?=$key->ra_name?></option>
                                                  <?php } }
                                                  ?>
                                                

                                                </select>
                                                  
                                                    
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Locations: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" value="<?=$key1->location?>"  type="text" name="location" id="loc"  >
                                                </div>
                                            </div>
                                            
                                             <div class="form-group">
                                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vender-name">Price: <span style="color:red">*</span></label>
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12"  type="text" value="<?=$key1->price?>" name="price" id="price"  >
                                                </div>
                                            </div>
                                         <span id="errornews" style="color:red" ></span>
                                                                               
                                            <div class="box-footer">
                                            <button type="button" class="btn btn-primary" onclick="news_check()">Submit</button>
                                            </div>
                                        </form>
                                    </div><!-- /.box -->
                                </div>
                            <?php }  ?>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
              <!--  <footer>
                    <div class="">
                        <p class="pull-right">Gentelella Alela! a Bootstrap 3 template by <a>Kimlabs</a>. |
                            <span class="lead"> <i class="fa fa-paw"></i> Gentelella Alela!</span>
                        </p>
                    </div>
                   <!--  <div class="clearfix"></div> -->
              <!--   </footer> --> 
                <!-- /footer content -->
            </div>
            <!-- /page content -->
        </div>
    </div>
    <script type="text/javascript">
  
        function news_check(){
        var pr=$('#pr_id').val();
        var loc=$('#loc').val();
        
        var news=$('#rad').val();
        if(news!=""  && loc!="" ){
            $.ajax({
                type: "POST",
                url: "<?=base_url();?>index.php/admindash/checkradiosprice/",
                 data: {news:news,loc:loc,pr:pr},
                success: function(result)   {
                    if(result==1){
                         document.getElementById("errornews").innerHTML = "";
                        $("#preevender").submit(); 
                    }else{
                      document.getElementById("errornews").innerHTML = "Same Radio Channel With Locatiom "+loc;
                      return false;
                    }
                }
                });
        }else{
            document.getElementById("errornews").innerHTML = "Some Mandatory Field Is Blank";
            return false;

        }
        

    }
    </script>
