 <div class="right_col" role="main">

                <br />
 <!-- page content -->
           <!--  <div class="right_col" role="main"> -->
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Add Category</h3>
                        </div>
<!-- 
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel" >
                                <div class="x_title">
                                    <h2>Add Category</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>                                   
                                </div>                             
                                <div class="row">
                                <!-- left column -->
                                    <div class="col-md-12">

                                        <form id="preevender" class="form-horizontal form-label-left" action="<?=base_url()?>insert-category" method="POST" role="form" enctype="multipart/form-data">
                                         <div class="form-group">
                                         <div class="input_fields_wrap">
                                                <label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-name">Category: <span style="color:red">*</span></label>
                                                <div class="col-md-3 col-sm-3 col-xs-12">
                                                    <input size="20" class="form-control col-md-7 col-xs-12" type="text" name="category[]" id="cat" Placeholder="Enter Category Name"  required  >
                                                    <span id="errornews" style="color:red" ></span>
                                                </div>
                                                <label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-Image">Image of Category: </label>
                                                <div class="col-md-3 col-sm-3 col-xs-12">
                                                    <input size="20"  type="file" name="image[]" required id="img"  >
                                                     <span id="errorimage" style="color:red" ></span>
                                                </div>
                                                <button class="add_field_button btn btn-success" value="+">+</button>
                                            </div>
                                            
                                         
                                         
                                                                               
                                            <div class="box-footer">
                                            <button type="submit" class="btn btn-primary" >Submit</button>
                                            </div>
                                        </form>
                                    </div><!-- /.box -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
              <!--  <footer>
                    <div class="">
                        <p class="pull-right">Gentelella Alela! a Bootstrap 3 template by <a>Kimlabs</a>. |
                            <span class="lead"> <i class="fa fa-paw"></i> Gentelella Alela!</span>
                        </p>
                    </div>
                   <!--  <div class="clearfix"></div> -->
              <!--   </footer> --> 
                <!-- /footer content -->
            </div>
            <!-- /page content -->
        </div>
    </div>
   <script type="text/javascript" src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
   <script> 
 $(document).ready(function() {
    var max_fields      = 30; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="form-group"><label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-name">Category: <span style="color:red">*</span></label><div class="col-md-3 col-sm-3 col-xs-12"><input size="20" class="form-control col-md-7 col-xs-12" type="text" name="category[]" id="cat" Placeholder="Enter Category Name"  required  ><span id="errornews" style="color:red" ></span></div><label class="control-label col-md-2 col-sm-3 col-xs-12" for="Category-Image">Image of Category: </label><div class="col-md-3 col-sm-3 col-xs-12"><input size="20"  type="file" name="image[]" required id="img"  ><span id="errorimage" style="color:red" ></span></div><a href="#" class="remove_field fa fa-close col-md-1 col-xs-12" style="color:red"></a></div>'); //add input box
        }
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
</script>

    <script type="text/javascript">
    function news_check(){
        var cat=$('#cat').val();
        var img=$('#img').val();
        if(cat!=""){
            if(img!=""){
                $.ajax({
                    type: "POST",
                    url: "<?=base_url();?>index.php/admindash/checkcat/",
                     data: {cat:cat},
                    success: function(result)   {
                        if(result==1){
                             document.getElementById("errornews").innerHTML = "";
                            $("#preevender").submit(); 
                        }else{
                          document.getElementById("errornews").innerHTML = "Category Is Used In Our List "+cat;
                          return false;
                        }
                    }
                });
            }else{
               document.getElementById("errorimage").innerHTML = "Image File Should Not Left Blank";
               return false; 
            }
        }else{
            document.getElementById("errornews").innerHTML = "Category Should Not Left Blank";
            return false;

        }
        

    }
    </script>
