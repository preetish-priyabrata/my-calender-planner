
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>
                    View Area Detail
                    <small>
                       
                    </small>
                </h3>
                        </div>

                        <!-- <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="clearfix"></div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>View Area <small>Detail</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <!-- <li><a href="#"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li> -->
                                        <li><a href="#" class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                 <div> 
                                    <a href="<?=base_url()?>add-area"  class="fa fa-plus-square text-success pull-right" style="font-size: 30px;"  ></a>
                                </div>
                                <div class="x_content">
                                    <table id="example" class="table table-striped responsive-utilities jambo_table">
                                        <thead>
                                            <tr class="headings">
                                                <th>Serial Nos</th>
                                                <th>City</th>
                                                <th>Area</th>
                                                <th>Status</th>
                                                <th >Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                        <?php 
                                        $x=1;
                                        $data=array('del_status'=>0);
                                        $this->db->order_by('city_id', 'asc');
                                        $query=$this->db->get_where('areas',$data);
                                        foreach ($query->result() as $key) {
                                            $city_code=$key->city_id;
                                            $data1=array('city_id'=>$city_code,'del_status'=>0);
                                            $querycity=$this->db->get_where('citys',$data1);
                                            if($querycity->num_rows()!=0){
                                                foreach ($querycity->result() as $value) {
                                                  $city_name=$value->city_name;
                                                  $status_city=$value->status;
                                                }
                                if($status_city==1){?>
                                                    <tr class="headings" >
                                                <th><?=$x?></th>
                                                <th><?=$city_name?></th>

                                                <th><?=$key->area_name?></th>
                                                <th><?php          
                                                        if ($key->status==1){
                                                    ?>
                                                            <a href="<?php echo site_url('update-area-status/2/'.$key->area_id)?>" name='active' class='badge bg-green' style='cursor:pointer;'>Active</a>
                                                    <?php 
                                                        }else{
                                                    ?>
                                                            <a href='<?php echo site_url('update-area-status/1/'.$key->area_id)?>' name='inactive' class='badge bg-red' style='cursor:pointer;'>Inactive</a>
                                                    <?php 
                                                        }                   
                                                    ?>
                                                </th>
                                               
                                                
                                                      
                                                <th ><a href="" class="fa fa-pencil-square-o" style="color:green" data-toggle="modal" data-target="#myeditmodal<?=$key->area_id?>"></a> || <a href="" class="fa fa-close" style="color:red" data-toggle="modal" data-target="#myModal<?=$key->area_id?>"></a></span>
                                                </th>
                                            </tr>
                                <?php }else{?>
                                                    <tr class="headings alert alert-warning" style="background:rgba(243, 156, 18, 0.88);">
                                                <th><?=$x?></th>
                                                <th><?=$city_name?></th>

                                                <th><?=$key->area_name?></th>
                                                <th><?php          
                                                        if ($key->status==1){
                                                    ?>
                                                            <a href="<?php echo site_url('update-area-status/2/'.$key->area_id)?>" name='active' class='badge bg-green' style='cursor:pointer;'>Active</a>
                                                    <?php 
                                                        }else{
                                                    ?>
                                                            <a href='<?php echo site_url('update-area-status/1/'.$key->area_id)?>' name='inactive' class='badge bg-red' style='cursor:pointer;'>Inactive</a>
                                                    <?php 
                                                        }                   
                                                    ?>
                                                </th>
                                               
                                                
                                                      
                                                <th ><a href="" class="fa fa-pencil-square-o" style="color:green" data-toggle="modal" data-target="#myeditmodal<?=$key->area_id?>"></a> || <a href="" class="fa fa-close" style="color:red" data-toggle="modal" data-target="#myModal<?=$key->area_id?>"></a></span>
                                                </th>
                                            </tr>
                         <?php } }   
                        ?>
                                       
            
                                             <!-- edit Modal -->
<div id="myeditmodal<?=$key->area_id?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:blue">Edit City</span></h4>
      </div>   
        <form id="preevender<?=$key->area_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>update-area" method="POST" role="form" enctype="multipart/form-data">
            <div class="modal-body" style="overflow: auto;">
                <div class="form-group">
                <label class="control-label col-md-2 col-sm-3 col-xs-12" for="City-name">City: <span style="color:red">*</span></label>
                    <div class="col-md-4 col-sm-3 col-xs-12">
                    <select class="form-control col-md-7 col-xs-12" name="city_id" id="city_id<?=$key->area_id?>">
                         <?php 
                          $city_code1=$key->city_id;
                                $data_city = array('del_status'=>0);
                                $query_city=$this->db->get_where('citys',$data_city);
                                if($query_city->num_rows()==0){
                                    echo '<option value="">--Add City--</option>';
                                }else{
                                    echo '<option value="">--Select City--</option>'; 
                                    foreach ($query_city->result() as $key12) {?>
                                    <option value="<?=$key12->city_id?>"<?php if($city_code1==$key12->city_id){ echo "selected"; }?>><?=$key12->city_name?></option>
                                        
                                <?php    }

                                }?>
                    </select>
                        
                    </div>
                    <label class="control-label col-md-2 col-sm-3 col-xs-12" for="City-name">City: <span style="color:red">*</span></label>
                    <div class="col-md-4 col-sm-3 col-xs-12">
                        <input type="hidden" name="area_id" value="<?=$key->area_id?>" id="area_id<?=$key->area_id?>">
                        <input size="20" class="form-control col-md-7 col-xs-12" type="text" value="<?=$key->area_name?>" name="area" id="area<?=$key->area_id?>" Placeholder="Enter Category Name"  required  >
                        <span id="errornews<?=$key->area_id?>" style="color:red" ></span>
                    </div>
                                                      
              </div>
            </div>
          <!-- <div class="modal-footer"> -->
            <div class="modal-footer">
                <button type="button" onclick="mycategory(<?=$key->area_id?>)" class="btn btn-primary" >Submit</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </form>
       
    </div>

  </div>
</div>
<!--edit modal -->                               
                                                <!-- Modal -->
<div id="myModal<?=$key->area_id?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><span style="color:red">Do You Want To Delete ...</span></h4>
      </div>
      <div class="modal-body">
        <form id="preevender<?=$key->area_id?>" class="form-horizontal form-label-left" action="<?=base_url()?>delete-area" method="POST" role="form" enctype="multipart/form-data">
            <input type="hidden" name="area_id" value="<?=$key->area_id?>" >
            <label> <b> Name</b> </label>: <?=$key->area_name?>.<br>
        
      </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-round btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-round btn-danger"  >Delete</button>
        
      </div>
    </div>
    </form>

  </div>
</div>
<!-- modal -->
                                            <?php 
                                                $x++;
                                            } ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                        <br />
                        <br />
                        <br />

                    </div>
                </div>
</div>


<script type="text/javascript">
    function mycategory(id){
        var cat=$('#area_id'+id).val();
        var catid=$('#city_id'+id).val();
        var area=$('#area'+id).val();
        if(catid!=""){
            if(area!=""){            
                $.ajax({
                    type: "POST",
                    url: "<?=base_url();?>index.php/admindash/checkarea/",
                     data: {cat:cat,catid:catid,area:area},
                    success: function(result)   {
                        if(result==1){
                             document.getElementById("errornews"+id).innerHTML = "";
                            $("#preevender"+id).submit(); 
                        }else{
                          document.getElementById("errornews"+id).innerHTML = "Area Is Used In Our List "+area;
                          return false;
                        }
                    }
                }); 
            }else{
               document.getElementById("errornews"+id).innerHTML = "Area Should Not Left Blank!!";
                return false;
 
            }          
        }else{
            document.getElementById("errornews"+id).innerHTML = "City Should Not Left Blank!!";
            return false;

        }
        

    }
    </script>